Just2Profit-এর বাকি ৩টি অংশ:
admin = Admin Panel
backend = API/Server starter
database = PostgreSQL schema

এগুলো starter files; production payment, admin security এবং full API এখনও সংযুক্ত করা হয়নি।
